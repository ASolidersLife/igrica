package com.example.kurs.alpha;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class Game extends AppCompatActivity {

    TextView Ime, Hp, Lvl, Xp;
    Button Predmeti, Magije, Udarac, O1, O2, O3, Odbrana, Glava, Telo, Rruka, Lruka, Rnoga, Lnoga;
    int p,n=0,str,def,adi,hp,sm,am,defm;
    double dm,hm,pd,ph,ndefm=0,nhp=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Ime = (TextView) findViewById(R.id.ImeV);
        Hp = (TextView) findViewById(R.id.HpV);
        Lvl = (TextView) findViewById(R.id.Lvl);
        Xp = (TextView) findViewById(R.id.Xp);

        SharedPreferences stats = getSharedPreferences("stats", Context.MODE_PRIVATE);
        Ime.setText(stats.getString("Ime", ""));
        Hp.setText("" + stats.getInt("Hp", 10));
        Lvl.setText("" + stats.getInt("Lvl", 1));
        Xp.setText("" + stats.getInt("Xp", 0));

        str=stats.getInt("Str", 0);
        def=stats.getInt("Def", 0);
        str=stats.getInt("Agi", 0);
        hp= Integer.parseInt(Hp.getText().toString());
        sm=stats.getInt("sm",0);
        defm=stats.getInt("dm",0);
        am=stats.getInt("am",0);

        Predmeti = (Button) findViewById(R.id.Predmeti);
        Magije = (Button) findViewById(R.id.Magije);
        Udarac = (Button) findViewById(R.id.Udarac);
        O1 = (Button) findViewById(R.id.Opcija_1);
        O2 = (Button) findViewById(R.id.Opcija_2);
        O3 = (Button) findViewById(R.id.Opcija_3);
        Odbrana = (Button) findViewById(R.id.Odbrana);
        Glava = (Button) findViewById(R.id.Glava);
        Telo = (Button) findViewById(R.id.Telo);
        Rruka = (Button) findViewById(R.id.Rruka);
        Lruka = (Button) findViewById(R.id.Lruka);
        Rnoga = (Button) findViewById(R.id.Rnoga);
        Lnoga = (Button) findViewById(R.id.Lnoga);

        Predmeti.setOnClickListener(Pred);
        Magije.setOnClickListener(Mag);
        Udarac.setOnClickListener(Udar);
        O1.setOnClickListener(Opt1);
        O2.setOnClickListener(Opt2);
        O3.setOnClickListener(Opt3);
        Odbrana.setOnClickListener(Odbr);
        Glava.setOnClickListener(Glv);
        Telo.setOnClickListener(Tlo);
        Rruka.setOnClickListener(Rr);
        Lruka.setOnClickListener(Lr);
        Rnoga.setOnClickListener(Rn);
        Lnoga.setOnClickListener(Ln);



    }

    View.OnClickListener Pred= new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(n==0)
            {
                p = 3;
                O1.setVisibility(View.VISIBLE);
                O1.setText("Napitak");
                O2.setVisibility(View.VISIBLE);
                O2.setText("Mana N");
                O3.setVisibility(View.VISIBLE);
                O3.setText("Bomba");
            }
            else if(n==1)
            {
                O1.setText("");
                O1.setVisibility(View.GONE);
                O1.setClickable(false);
                O2.setText("");
                O2.setVisibility(View.GONE);
                O2.setClickable(false);
                O3.setText("");
                O3.setVisibility(View.GONE);
                O3.setClickable(false);
                Udarac.setClickable(true);
                Magije.setClickable(true);
                n=0;
                p=0;
            }
        };
    };
    View.OnClickListener Mag = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(n==0) {
                p = 2;
                O1.setVisibility(View.VISIBLE);
                O1.setText("Vatra");
                O2.setVisibility(View.VISIBLE);
                O2.setText("Munja");
                O3.setVisibility(View.VISIBLE);
                O3.setText("Led");
            }
            else if(n==1)
            {
                O1.setText("");
                O1.setVisibility(View.GONE);
                O1.setClickable(false);
                O2.setText("");
                O2.setVisibility(View.GONE);
                O2.setClickable(false);
                O3.setText("");
                O3.setVisibility(View.GONE);
                O3.setClickable(false);
                Udarac.setClickable(true);
                Predmeti.setClickable(true);
                n=0;
                p=0;
            }

        };
    };
    View.OnClickListener Udar = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(n==0) {
                p = 1;
                O1.setVisibility(View.VISIBLE);
                O1.setText("Spor");
                O2.setVisibility(View.VISIBLE);
                O2.setText("Munja");
                O3.setVisibility(View.VISIBLE);
                O3.setText("Led");
            }
            else if(n==1)
            {
                O1.setText("");
                O1.setVisibility(View.GONE);
                O1.setClickable(false);
                O2.setText("");
                O2.setVisibility(View.GONE);
                O2.setClickable(false);
                O3.setText("");
                O3.setVisibility(View.GONE);
                O3.setClickable(false);
                Magije.setClickable(true);
                Predmeti.setClickable(true);
                n=0;
                p=0;
            }
        };
    };
    View.OnClickListener Opt1= new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            switch (p)
            {
                case 1:
                    Glava.setClickable(true);
                    Telo.setClickable(true);
                    Lruka.setClickable(true);
                    Rruka.setClickable(true);
                    Lnoga.setClickable(true);
                    Rnoga.setClickable(true);
                    ph=0.4;
                    pd=-0.4;
                    break;
                case 2:

                    break;
                case 3:
                    break;
                default:
                    break;
            }

        };
    };
    View.OnClickListener Opt2 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            switch (p)
            {
                case 1:
                    Glava.setClickable(true);
                    Telo.setClickable(true);
                    Lruka.setClickable(true);
                    Rruka.setClickable(true);
                    Lnoga.setClickable(true);
                    Rnoga.setClickable(true);
                    ph=0;
                    pd=0;
                    break;
                case 2:

                    break;
                case 3:
                    break;
                default:
                    break;
            }
        };
    };
    View.OnClickListener Opt3 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (p)
            {
                case 1:
                    Glava.setClickable(true);
                    Telo.setClickable(true);
                    Lruka.setClickable(true);
                    Rruka.setClickable(true);
                    Lnoga.setClickable(true);
                    Rnoga.setClickable(true);
                    ph=0.5;
                    pd=-0.5;
                    break;
                case 2:

                    break;
                case 3:
                    break;
                default:
                    break;
            }

        };
    };
    View.OnClickListener Odbr = new View.OnClickListener() {
        @Override
        public void onClick(View v) {


        };
    };
    View.OnClickListener Glv = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            ph-=0.2;
            pd+=0.4;
            if(ndefm< napad())
            {
                nhp-=dmg();
            }
        };
    };
    View.OnClickListener Tlo= new View.OnClickListener() {
        @Override
        public void onClick(View v) {


        };
    };
    View.OnClickListener Rr= new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            ph-=0.1;
            pd+=0.1;

        };
    };
    View.OnClickListener Lr= new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            ph-=0.1;
            pd+=0.1;


        };
    };
    View.OnClickListener Rn= new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            ph-=0.1;
            pd+=0.1;


        };
    };
    View.OnClickListener Ln= new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            ph-=0.1;
            pd+=0.1;


        };
    };

    public double napad()
    {
        Random r= new Random();

        return r.nextInt(20) + sm + sm*ph;
    }
    public double dmg()
    {
        Random r=new Random();
        return r.nextInt(8) + sm +sm*pd;
    }

}
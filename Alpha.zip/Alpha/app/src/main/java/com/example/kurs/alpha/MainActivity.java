package com.example.kurs.alpha;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {
    Button start, load, exit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        start = (Button) findViewById(R.id.newgame);
        load = (Button) findViewById(R.id.loadgame);
        exit = (Button) findViewById(R.id.exit);

        start.setOnClickListener(newg);
        load.setOnClickListener(loadg);
        exit.setOnClickListener(exitg);

        SharedPreferences stats = getSharedPreferences("stats", Context.MODE_PRIVATE);
        int Str = stats.getInt("Str", 0);
        int Agi = stats.getInt("Agi", 0);
        int Def = stats.getInt("Def", 0);
        String ime = stats.getString("Ime", "");
        boolean newgame=stats.getBoolean("ng", false);
        boolean lvlup=stats.getBoolean("lvl", false);
        int HP = stats.getInt("Hp",10);
    }

    View.OnClickListener newg = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            SharedPreferences stats = getSharedPreferences("stats", Context.MODE_PRIVATE);
            SharedPreferences.Editor edit = stats.edit();
            edit.putBoolean("ng",true);
            edit.commit();
            Intent intent = new Intent(getBaseContext(),Ng.class);
            startActivity(intent);
        }
    };

    View.OnClickListener loadg = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(getBaseContext(), Game.class);
            startActivity(intent);
        }
    };

    View.OnClickListener exitg = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

        }
    };

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}

package com.example.kurs.alpha;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.content.Intent;


public class Stats extends AppCompatActivity {

    TextView Str, Agi, Def, Hp, Poeni, Ime;
    Button Strup, Strdown, Agiup, Agidown, Defup, Defdown, Commit, Kraj;
    int p, sm, dm, am;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stats);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        SharedPreferences stats = getSharedPreferences("stats", Context.MODE_PRIVATE);

        Ime = (TextView)findViewById(R.id.VIme);
        String ime = stats.getString("Ime", "").toString();
        Ime.setText(ime);

        Str = (TextView)findViewById(R.id.Str);
        int str = stats.getInt("Str", 0);
        Str.setText("" + str);

        Agi = (TextView)findViewById(R.id.Agi);
        int agi = stats.getInt("Agi", 0);
        Agi.setText("" + agi);

        Def = (TextView)findViewById(R.id.Def);
        int def = stats.getInt("Def", 0);
        Def.setText("" + def);

        Hp = (TextView)findViewById(R.id.HP);
        int hp = stats.getInt("Hp", 10);
        Hp.setText("" + hp);

        if(stats.getBoolean("ng", false)){
            Strup.setEnabled(true);
            Strdown.setEnabled(true);
            Defup.setEnabled(true);
            Defdown.setEnabled(true);
            Agiup.setEnabled(true);
            Agidown.setEnabled(true);
            p=10;
        }

        if(stats.getBoolean("lvl", false)){
            Strup.setEnabled(true);
            Strdown.setEnabled(true);
            Defup.setEnabled(true);
            Defdown.setEnabled(true);
            Agiup.setEnabled(true);
            Agidown.setEnabled(true);
            p=3;
        }

        Poeni = (TextView)findViewById(R.id.Poeni);
        Poeni.setText("" + p);

        Strup = (Button)findViewById(R.id.Strup);
        Strdown = (Button)findViewById(R.id.Strdown);

        Agiup = (Button)findViewById(R.id.Agiup);
        Agidown = (Button)findViewById(R.id.Agidown);

        Defup = (Button)findViewById(R.id.Defup);
        Defdown = (Button)findViewById(R.id.Defdown);

        Commit = (Button)findViewById(R.id.Commit);
        Kraj = (Button)findViewById(R.id.Kraj);



        Strup.setOnClickListener(Sup);
        Strdown.setOnClickListener(Sdown);

        Agiup.setOnClickListener(Aup);
        Agidown.setOnClickListener(Adown);

        Defup.setOnClickListener(Dup);
        Defdown.setOnClickListener(Ddown);

        Commit.setOnClickListener(Com);
        Kraj.setOnClickListener(kraj);


    }

    View.OnClickListener Sup = new View.OnClickListener(){
        @Override
        public void onClick(View v) {
            int r = Integer.parseInt(Str.getText().toString());
            if(p>0){
                r++;
                p--;
                Str.setText("" + r);
                Poeni.setText("" + p);
                if(p % 2 == 0){
                    sm++;
                    Hp.setText(""+(10+sm));
                }
            }
        }
    };

    View.OnClickListener Sdown = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            int r = Integer.parseInt(Str.getText().toString());
            if(r>0){
                r--;
                p++;
                Str.setText("" + r);
                Poeni.setText("" + p);
                if(p % 2 == 0){
                    sm--;
                    Hp.setText(""+(10+sm));
                }
            }
        }
    };

    View.OnClickListener Aup = new View.OnClickListener(){
        @Override
        public void onClick(View v){
            int r = Integer.parseInt(Agi.getText().toString());
            if(p>0){
                r++;
                p--;
                Agi.setText("" + r);
                Poeni.setText("" + p);
                if(p % 2 == 0){
                    am++;
                }
            }
        }
    };

    View.OnClickListener Adown = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            int r = Integer.parseInt(Agi.getText().toString());
            if(r>0){
                r--;
                p++;
                Agi.setText("" + r);
                Poeni.setText("" + p);
                if(p % 2 == 0){
                    am--;
                }
            }
        }
    };

    View.OnClickListener Dup = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            int r = Integer.parseInt(Def.getText().toString());
            if(p>0){
                r++;
                p--;
                Def.setText("" + r);
                Poeni.setText("" + p);
                if(p % 2 == 0){
                    dm++;
                }
            }
        }
    };
    View.OnClickListener Ddown = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            int r = Integer.parseInt(Def.getText().toString());
            if(r>0){
                r--;
                p++;
                Def.setText("" + r);
                Poeni.setText("" + p);
                if(p % 2 == 0){
                    dm--;
                }
            }
        }
    };

    View.OnClickListener Com = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            SharedPreferences stats = getSharedPreferences("stats", Context.MODE_APPEND);
            SharedPreferences.Editor edit = stats.edit();
            edit.putInt("Str", Integer.parseInt(Str.getText().toString()));
            edit.putInt("Agi", Integer.parseInt(Agi.getText().toString()));
            edit.putInt("Def", Integer.parseInt(Def.getText().toString()));
            edit.putInt("Hp", Integer.parseInt(Hp.getText().toString()));
            edit.putInt("sm", sm);
            edit.putInt("am", am);
            edit.putInt("dm", dm);

            edit.putBoolean("lvl", false);
            edit.putBoolean("ng", false);

            if(p==0){
                Strup.setEnabled(false);
                Strdown.setEnabled(false);
                Defup.setEnabled(false);
                Defdown.setEnabled(false);
                Agiup.setEnabled(false);
                Agidown.setEnabled(false);
            }
        }
    };

    View.OnClickListener kraj = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(getBaseContext(), Game.class);
            startActivity(intent);
        }
    };
}


